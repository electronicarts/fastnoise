This gaussian noise is in [0,1].
Subtract 0.5 and divide by 0.15 to make it into sigma 1.0 noise.
You can then multiply it by the sigma you want.